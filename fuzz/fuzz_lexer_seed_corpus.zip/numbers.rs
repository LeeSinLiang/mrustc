fn test() {
    let a = 42;
    let b = 0x1234;
    let c = 0b1010;
    let d = 3.14;
    let e = 1e10;
}

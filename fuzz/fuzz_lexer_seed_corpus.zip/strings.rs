fn test() {
    let s = "hello";
    let r = r#"raw string"#;
    let b = b"bytes";
    let c = 'x';
}
